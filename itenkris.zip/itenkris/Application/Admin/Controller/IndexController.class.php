<?php
namespace Admin\Controller;
use Think\Controller;
class IndexController extends BaseController {
    public function index(){
        $this->display();
    }
	public function left(){
        $this->display();
    }
	public function main(){
        $this->display();
    }
	public function top(){
        $this->display();
    }
}