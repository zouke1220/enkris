<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>苏州晶湛半导体有限公司</title>
<meta name="robots" content="noindex, nofollow">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="/Public/Admin/Styles/general.css" rel="stylesheet" type="text/css" />
<link href="/Public/Admin/Styles/main.css" rel="stylesheet" type="text/css" />
</head>
<body>
<h1>
    <span class="action-span1"><a href="#">苏州晶湛半导体有限公司后台管理中心</a> </span>
    <span id="search_id" class="action-span1"></span>
    <div style="clear:both"></div>
</h1>
<!-- start system information -->
<div class="list-div">
    <table cellspacing='1' cellpadding='3'>
        <tr>
            <th colspan="4" class="group-title">系统信息</th>
        </tr>
        <tr>
            <td width="20%">服务器操作系统:</td>
            <td width="30%">WINNT (127.0.0.1)</td>
            <td width="20%">Web 服务器:</td>
            <td width="30%">Apache/2.2.22 (Win32) PHP/5.3.8</td>
        </tr>
        <tr>
            <td>PHP 版本:</td>
            <td>5.3.8</td>
            <td>MySQL 版本:</td>
            <td>5.5.24</td>
        </tr>
    </table>
</div>
<div id="footer">
     powerd by thinkphp--邹柯
</div>
</body>
</html>